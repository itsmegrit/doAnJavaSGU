package DTO;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author kienn
 */
public class NhanVienDTO {
    private int maNhanVien, luong;
    private String hoVaTen, ngayThangNamSinh; 
    public NhanVienDTO(){}
    public int getMaNhanVien() {
        return maNhanVien;
    }

    public int getLuong() {
        return luong;
    }

    public String getHoVaTen() {
        return hoVaTen;
    }

    public String getNgayThangNamSinh() {
        return ngayThangNamSinh;
    }
    public void setMaNhanVien(int maNhanVien) {
        this.maNhanVien = maNhanVien;
    }
    public void setLuong(int luong) {
        this.luong = luong;
    }
    public void setHoVaTen(String hoVaTen) {
        this.hoVaTen = hoVaTen;
    }
    public void setNgayThangNamSinh(String ngayThangNamSinh) {
        this.ngayThangNamSinh = ngayThangNamSinh;
    }
}
