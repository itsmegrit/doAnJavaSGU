/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author vuong
 */
public class KhachHangDTO {
    int maKhachHang;
    String hoVaTen, diaChi, SDT;

    public KhachHangDTO(int maKhachHang, String hoVaTen, String diaChi, String SDT) {
        this.maKhachHang = maKhachHang;
        this.hoVaTen = hoVaTen;
        this.diaChi = diaChi;
        this.SDT = SDT;
    }

    public KhachHangDTO() {
    }

    public int getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(int maKhachHang) {
        this.maKhachHang = maKhachHang;
    }

    public String getHoVaTen() {
        return hoVaTen;
    }

    public void setHoVaTen(String hoVaTen) {
        this.hoVaTen = hoVaTen;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }
    
    
}

