/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.util.Vector;

/**
 *
 * @author ngtph
 */
public class DonHangDTO {
    private int maDonHang, tongTien, maKhachHang;
    private String trangThai, ngayDat;
    private Vector<SanPhamDTO> danhSachSanPham;

    public int getMaDonHang() {
        return maDonHang;
    }

    public void setMaDonHang(int maDonHang) {
        this.maDonHang = maDonHang;
    }

    public int getTongTien() {
        return tongTien;
    }

    public void setTongTien(int tongTien) {
        this.tongTien = tongTien;
    }

    public int getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(int maKhachHang) {
        this.maKhachHang = maKhachHang;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public String getNgayDat() {
        return ngayDat;
    }

    public void setNgayDat(String ngayDat) {
        this.ngayDat = ngayDat;
    }

    public Vector<SanPhamDTO> getDanhSachSanPham() {
        return danhSachSanPham;
    }

    public void setDanhSachSanPham(Vector<SanPhamDTO> danhSachSanPham) {
        this.danhSachSanPham = danhSachSanPham;
    }

    public DonHangDTO(int maDonHang, int tongTien, int maKhachHang, String trangThai, String ngayDat, Vector<SanPhamDTO> danhSachSanPham) {
        this.maDonHang = maDonHang;
        this.tongTien = tongTien;
        this.maKhachHang = maKhachHang;
        this.trangThai = trangThai;
        this.ngayDat = ngayDat;
        this.danhSachSanPham = danhSachSanPham;
    }

    public DonHangDTO() {
    }    
}
