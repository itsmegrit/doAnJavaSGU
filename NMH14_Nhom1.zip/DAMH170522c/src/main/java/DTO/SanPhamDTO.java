/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author ngtph
 */
public class SanPhamDTO {
    
    private int maSanPham, soLuong, gia, loaiID;
    private String tenSanPham, maLoai;

    public SanPhamDTO(int maSanPham, int soLuong, int gia, String tenSanPham, int loaiID,String maLoai) {
        this.maSanPham = maSanPham;
        this.soLuong = soLuong;
        this.gia = gia;
        this.tenSanPham = tenSanPham;
        this.loaiID = loaiID;
        this.maLoai = maLoai;
    }

    public SanPhamDTO() {
    }

    public int getMaSanPham() {
        return maSanPham;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public int getGia() {
        return gia;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public int getLoaiID() {
        return loaiID;
    }

    public void setMaSanPham(int maSanPham) {
        this.maSanPham = maSanPham;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public void setGia(int gia) {
        this.gia = gia;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public void setLoaiID(int loaiID) {
        this.loaiID = loaiID;
    }

    public String getMaLoai() {
        return maLoai;
    }

    public void setMaLoai(String maLoai) {
        this.maLoai = maLoai;
    }
    
    
}
