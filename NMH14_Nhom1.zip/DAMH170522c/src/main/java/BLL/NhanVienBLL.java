/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BLL;

import DAO.NhanVienDAO;
import DTO.NhanVienDTO;
import java.sql.SQLException;
import java.util.Vector;

/**
 *
 * @author kienn
 */
public class NhanVienBLL {
    NhanVienDAO nvienDAO = new NhanVienDAO();
    public Vector<NhanVienDTO> getAllNhanVien() throws ClassNotFoundException, SQLException{
        return nvienDAO.getAllNhanVien();
    } 
    
    public String themNhanVien(NhanVienDTO nhanVien) throws ClassNotFoundException, SQLException{
        String hoVaTen = nhanVien.getHoVaTen();
        if(nvienDAO.kiemTraDaCoNhanVien(hoVaTen)){
            return "Exist";
        }
        if(nvienDAO.themNhanVien(nhanVien)){
            return "Success";
        }
        return "Add failure";
    }
    
    public boolean xoaNhanVien(int maNhanVien) throws ClassNotFoundException, SQLException{
        return nvienDAO.xoaNhanVien(maNhanVien);
    }
    
    public String suaNhanVien(NhanVienDTO nhanVien) throws ClassNotFoundException, SQLException{
        if(nvienDAO.suaNhanVien(nhanVien)){
            return "Sửa thành công nhân viên có mã là: " + nhanVien.getMaNhanVien();
        }
        return "Sửa thông tin nhân viên thất bại";
    }
    public Vector<NhanVienDTO> timNhanVienTheoHoTen(String hoVaTen) throws ClassNotFoundException, SQLException {
        return nvienDAO.timTheoTen(hoVaTen);
    }
    public Vector<NhanVienDTO> timNhanVienTheoMa(int maNhanVien) throws ClassNotFoundException, SQLException{
        return nvienDAO.timTheoMa(maNhanVien);
    }
}
