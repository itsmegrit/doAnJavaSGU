/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BLL;

import DTO.KhachHangDTO;
import DAO.KhachHangDAO;
import DTO.NhanVienDTO;
import java.sql.SQLException;
import java.util.Vector;

public class KhachHangBLL {
    //Tạo vector lấy toàn bộ sản phẩm trong csdl
    KhachHangDAO kHangDAO = new KhachHangDAO();
    public Vector<KhachHangDTO> getAllKhachHang() throws SQLException, ClassNotFoundException{        
        return kHangDAO.getAllKhachHang();        
    }
    
//    Thêm khách hàng vào bảng khách hàng
    public boolean addKhachHang(KhachHangDTO khachHang) throws ClassNotFoundException, SQLException{
        return kHangDAO.addKhachHang(khachHang);
    }
    
    public String updateKhachHang(KhachHangDTO khachHang) throws ClassNotFoundException, SQLException{
        if(kHangDAO.updateKhachHang(khachHang)){
            return "Success";
        }
        return "Update failure";
    }
    public Vector<KhachHangDTO> timKhachHangTheoHoTen(String hoVaTen) throws ClassNotFoundException, SQLException {
        return kHangDAO.timTheoTen(hoVaTen);
    }
    public Vector<KhachHangDTO> timKhachHangTheoMa(int maNhanVien) throws ClassNotFoundException, SQLException{
        return kHangDAO.timTheoMa(maNhanVien);
    }
    
    public String hasKhachHang(int ID) throws ClassNotFoundException, SQLException{
        if(kHangDAO.hasKhachHang(ID)){
            return "Tìm thấy khách hàng";
        }
        return "Không tìm thấy mã khách hàng";
    }
}
