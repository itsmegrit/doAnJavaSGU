/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BLL;

import DAO.LoaiDAO;
import DTO.LoaiDTO;
import java.sql.SQLException;
import java.util.Vector;

/**
 *
 * @author ngtph
 */
public class LoaiBLL {
    LoaiDAO newLoaiDAO = new LoaiDAO();
    public boolean hasLoai(String maLoai) throws SQLException, ClassNotFoundException{
        return newLoaiDAO.hasLoai(maLoai);
    }
    
    public LoaiDTO findLoai(int loaiID) throws ClassNotFoundException, SQLException{
        return newLoaiDAO.findLoai(loaiID);
    }
    
    public Vector<LoaiDTO> getAllLoai() throws ClassNotFoundException, SQLException{
        return newLoaiDAO.getAllLoai();
    }
    
    public String addLoai(LoaiDTO loai) throws ClassNotFoundException, SQLException {
        if(newLoaiDAO.hasLoai(loai.getMaLoai())){
            return "Exist";
        }
        if(newLoaiDAO.addLoai(loai)){
            return "Success";
        }
        return "add failure";
    }
}
