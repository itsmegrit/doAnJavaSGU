/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BLL;

import DAO.SanPhamDAO;
import DTO.LoaiDTO;
import DTO.SanPhamDTO;
import java.sql.SQLException;
import java.util.Vector;

/**
 *
 * @author ngtph
 */
public class SanPhamBLL {
// Xử lí lấy về toàn bộ sản phẩm có trong cơ sỡ dữ liệu
    SanPhamDAO sPhamDAO = new SanPhamDAO();
    public Vector<SanPhamDTO> getAllSanPham() throws ClassNotFoundException, SQLException{
        return sPhamDAO.getAllSanPham();
    }
    
// Xử lí thêm một sản phẩm vào cơ sỡ dữ liệu
    public String addSanPham(SanPhamDTO sanPham) throws ClassNotFoundException, SQLException{
        String tenSP = sanPham.getTenSanPham(); // lấy tên sản phẩm
        // nếu sản phẩm đã tồn tại trong cơ sở dữ liệu
        if(sPhamDAO.hasSanPham(tenSP)){
            return "exist";
        }
        // nếu sản phẩm được thêm thành công
        if(sPhamDAO.addSanPham(sanPham)){
            return "success";
        }
        // thêm thất bại
        return "add failure";
    }
    
    public boolean deleteSanPham(int id) throws ClassNotFoundException, SQLException{
        return sPhamDAO.deleteSanPham(id);
    }
    
    public String updateSanPham(SanPhamDTO sanPham) throws ClassNotFoundException, SQLException{
        if(sPhamDAO.updateSanPham(sanPham)){
            return "Cập nhật thành công sản phẩm có mã là: " + sanPham.getMaSanPham();
        }
        return "Cập nhật thất bại";
    }
    
    public Vector<SanPhamDTO> timSanPham(String input, int option) throws ClassNotFoundException, SQLException{
        
        if (option == 1){
            return sPhamDAO.timTheoTen(input);
        }
        if (option == 0){
            return sPhamDAO.timTheoMa(Integer.parseInt(input));
        }
        if (option == 2) {
            return sPhamDAO.timTheoLoai(input);
        } else {
            return null;
        }
    }
    
    public String kiemTraSanPham(int ID) throws ClassNotFoundException, SQLException{
        if(sPhamDAO.kiemTraSanPham(ID)){
            return "Tìm thấy sản phẩm có mã là "+ID;
        }
        return "Không tìm thấy sản phẩm có mã "+ID;
    }
}
