/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BLL;

import DAO.DonHangDAO;
import DTO.DonHangDTO;
import java.sql.SQLException;
import java.util.Vector;

/**
 *
 * @author ngtph
 */
public class DonHangBLL {
    DonHangDAO donHangDAO = new DonHangDAO();

    public boolean taoMoiDonHang(int maKhachHang) throws ClassNotFoundException, SQLException{
        return donHangDAO.taoDonHang(maKhachHang);
    }
    
    public Vector<DonHangDTO> getAllDonHang() throws ClassNotFoundException, SQLException{
        return donHangDAO.getAllDonHang();
    }
}
