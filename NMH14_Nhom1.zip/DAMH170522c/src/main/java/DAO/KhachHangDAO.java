/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DAO.DBHelper;
import DTO.KhachHangDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
        
public class KhachHangDAO {
    // Lấy tất cả khách hàng từ cơ sở dữ liệu
    public Vector<KhachHangDTO> getAllKhachHang() throws SQLException, ClassNotFoundException{
        Vector<KhachHangDTO> khachHangArr = new Vector<KhachHangDTO>();
        String sql = "select * from KHACHHANG";
        try (
                Connection conn = DBHelper.OpenConnection();
                Statement stmt = conn.createStatement();
            ){
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                KhachHangDTO kHang = new KhachHangDTO();
                kHang.setMaKhachHang(rs.getInt("maKhachHang"));
                kHang.setHoVaTen(rs.getString("hoVaTen"));
                kHang.setDiaChi(rs.getString("diaChi"));
                kHang.setSDT(rs.getString("SDT"));
                khachHangArr.add(kHang);
            }
        }
        return khachHangArr;
    }
    
//    Thêm khách hàng vào bảng khách hàng
    public boolean addKhachHang(KhachHangDTO khachHang) throws ClassNotFoundException, SQLException{
        boolean res = false;
        String sql = "insert into KHACHHANG (hoVaTen, SDT, diaChi) values (?, ?, ?)";
        
        try (
                Connection conn = DBHelper.OpenConnection();
                PreparedStatement pstmt = conn.prepareCall(sql);
            ) {
            pstmt.setString(1, khachHang.getHoVaTen());
            pstmt.setString(2, khachHang.getSDT());
            pstmt.setString(3, khachHang.getDiaChi());
            
            if(pstmt.executeUpdate()>=1){
                res = true;
            }
        }
        return res;
    }
    
    public boolean hasKhachHang(int ID) throws ClassNotFoundException, SQLException{
        boolean res = false;
        String sql = "select * from KHACHHANG where maKhachHang = " + ID;
        try(Connection conn = DBHelper.OpenConnection(); Statement stmt = conn.createStatement();){
            ResultSet rs = stmt.executeQuery(sql);
            if(rs.next()){
                res = true;
            }
        }
        return res;
    }
    
    public boolean updateKhachHang(KhachHangDTO khachHang) throws ClassNotFoundException, SQLException{
        boolean res = false;
        String sql = "update KHACHHANG set hoVaTen = ?, SDT = ?, diaChi = ? where maKhachHang = ?";
        
        try (
            Connection conn = DBHelper.OpenConnection();
            PreparedStatement pstmt = conn.prepareCall(sql);
            ) {
            pstmt.setInt(4, khachHang.getMaKhachHang());
            pstmt.setString(1, khachHang.getHoVaTen());
            pstmt.setString(2, khachHang.getSDT());
            pstmt.setString(3, khachHang.getDiaChi());
            if(pstmt.executeUpdate()>=1){
                res=true;
            }
        }
        return res;
    }
    public Vector<KhachHangDTO> timTheoMa(int maKhachHang) throws ClassNotFoundException, SQLException {
        Vector<KhachHangDTO> khachHangArr = new Vector<KhachHangDTO>();
        String sql = "select * from KHACHHANG where maKhachHang = " + maKhachHang;
        try(
                Connection conn = DBHelper.OpenConnection();
                Statement stmt = conn.createStatement();
                ){
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()) {
                KhachHangDTO khachHang = new KhachHangDTO();
                khachHang.setMaKhachHang(rs.getInt("maKhachHang"));
                khachHang.setHoVaTen(rs.getString("hoVaTen"));
                khachHang.setDiaChi(rs.getString("diaChi"));
                khachHang.setSDT(rs.getString("SDT"));
                khachHangArr.add(khachHang);
            }
        }
        return khachHangArr;
    }
    
    public Vector<KhachHangDTO> timTheoTen(String hoVaTenKhachHang) throws ClassNotFoundException, SQLException {
        Vector<KhachHangDTO> khachHangArr = new Vector<KhachHangDTO>();
        String sql = "select * from KHACHHANG where hoVaTen like '%"+ hoVaTenKhachHang +"%'";
        try(
                Connection conn = DBHelper.OpenConnection();
                Statement stmt = conn.createStatement();
                ){
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()) {
                KhachHangDTO khachHang = new KhachHangDTO();
                khachHang.setMaKhachHang(rs.getInt("maKhachHang"));
                khachHang.setHoVaTen(rs.getString("hoVaTen"));
                khachHang.setDiaChi(rs.getString("diaChi"));
                khachHang.setSDT(rs.getString("SDT"));
                khachHangArr.add(khachHang);
            }
        }
        return khachHangArr;
    }
}

