/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.DonHangDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author ngtph
 */
public class DonHangDAO {
    public boolean taoDonHang(int maKhachHang) throws ClassNotFoundException, SQLException{
        boolean res = false;
        String sql = "insert into DONHANG (maKhachHang) values (?)";
        try(Connection conn = DBHelper.OpenConnection(); PreparedStatement pstmt = conn.prepareCall(sql);){
            pstmt.setInt(1, maKhachHang);
            if(pstmt.executeUpdate()>=1){
                res=true;
            }
        }
        return res;
    }
    
    public Vector<DonHangDTO> getAllDonHang() throws ClassNotFoundException, SQLException{
        Vector<DonHangDTO> donHangArr = new Vector<DonHangDTO>();
        String sql = "select * from DONHANG";
        try(Connection conn = DBHelper.OpenConnection(); Statement stmt = conn.createStatement();){
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                DonHangDTO donHangDTO = new DonHangDTO();
                donHangDTO.setMaDonHang(rs.getInt("maDonHang"));
                donHangDTO.setMaKhachHang(rs.getInt("maKhachHang"));
                donHangDTO.setNgayDat(rs.getString("ngayDat"));
                donHangDTO.setTrangThai(rs.getString("trangThai"));
                donHangDTO.setTongTien(rs.getInt("tongTien"));
                donHangArr.add(donHangDTO);
            }
        }
        return donHangArr;
    }
    
}
