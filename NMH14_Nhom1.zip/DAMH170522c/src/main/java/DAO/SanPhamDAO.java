/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.LoaiDTO;
import DTO.SanPhamDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author ngtph
 */
public class SanPhamDAO {
// Lấy tất cả sản phẩm từ cơ sở dữ liệu
   public Vector<SanPhamDTO> getAllSanPham() throws ClassNotFoundException, SQLException{
       Vector<SanPhamDTO> sanPhamArr = new Vector<SanPhamDTO>();
       String sql = "select maSanPham, tenSanPham, gia, soluong, loaisanpham.maloai\n" +
                    "from sanpham, loaisanpham\n" +
                    "where sanpham.maLoai = loaisanpham.loaiID";
       try (
               Connection conn = DBHelper.OpenConnection();
               Statement stmt = conn.createStatement();
            ) {
           ResultSet rs = stmt.executeQuery(sql);
           
           while(rs.next()){
               SanPhamDTO sanPham = new SanPhamDTO();
               sanPham.setMaSanPham(rs.getInt("maSanPham"));
               sanPham.setTenSanPham(rs.getString("tenSanPham"));
               sanPham.setMaLoai(rs.getString("maLoai"));
               sanPham.setGia(rs.getInt("gia"));
               sanPham.setSoLuong(rs.getInt("soLuong"));
               sanPhamArr.add(sanPham);
           }
       }
       return sanPhamArr;
   }
   
// Thêm một sản phẩm vào cơ sỡ dữ liệu
   
  public boolean addSanPham(SanPhamDTO sanPham) throws ClassNotFoundException, SQLException{
      boolean res = false;
      String sql = "insert into SANPHAM (tenSanPham, soLuong, gia, maLoai) values (?,?,?,?)";
      try(
            Connection conn = DBHelper.OpenConnection();
            PreparedStatement pstmt = conn.prepareCall(sql);
          ){
          pstmt.setString(1, sanPham.getTenSanPham());
          pstmt.setInt(2, sanPham.getSoLuong());
          pstmt.setInt(3, sanPham.getGia());
          pstmt.setInt(4, sanPham.getLoaiID());
          
          if(pstmt.executeUpdate()>=1){
              res = true;
          }
      }
      return res;
  }

//  kiểm tra xem sản phẩm có trong csdl chưa?
  public boolean hasSanPham(String name) throws ClassNotFoundException, SQLException{
      boolean res = false;
      String sql = "select * from SANPHAM where tenSanPham='"+name+"'";
      try(
              Connection conn = DBHelper.OpenConnection();
              Statement stmt =conn.createStatement();
          ){
          ResultSet rs = stmt.executeQuery(sql);
          res = rs.next();
      }
      return res;
  }
  
    public boolean kiemTraSanPham(int ID) throws ClassNotFoundException, SQLException{
      boolean res = false;
      String sql = "select * from SANPHAM where maSanPham="+ID;
      try(
              Connection conn = DBHelper.OpenConnection();
              Statement stmt =conn.createStatement();
          ){
          ResultSet rs = stmt.executeQuery(sql);
          res = rs.next();
      }
      return res;
  }
  
  public boolean deleteSanPham(int id) throws ClassNotFoundException, SQLException{
      boolean res = false;
      String sql = "DELETE FROM SANPHAM WHERE maSanPham =" + id;
      try(
          Connection conn = DBHelper.OpenConnection();
          Statement stmt = conn.createStatement();
          ){
          if(stmt.executeUpdate(sql)>= 1){
              res = true;
          }
      }
      return res;
  }
  
  public boolean updateSanPham(SanPhamDTO sanPham) throws ClassNotFoundException, SQLException{
      boolean res = false;
      String sql = "update SANPHAM set tenSanPham = ?, gia = ?, soLuong = ?, maLoai = ? where maSanPham = ?";
      try(Connection conn = DBHelper.OpenConnection(); PreparedStatement pstmt = conn.prepareCall(sql);){
          pstmt.setInt(5, sanPham.getMaSanPham());
          pstmt.setString(1, sanPham.getTenSanPham());
          pstmt.setInt(2, sanPham.getGia());
          pstmt.setInt(3, sanPham.getSoLuong());
          pstmt.setInt(4, sanPham.getLoaiID());
          if(pstmt.executeUpdate()>=1){
              res=true;
          }
      }
      return res;
  }
  
  public Vector<SanPhamDTO> timTheoMa(int ID) throws ClassNotFoundException, SQLException {
      Vector<SanPhamDTO> sanPhamArr = new Vector<SanPhamDTO>();
      String sql =  "select maSanPham, tenSanPham, gia, soluong, loaisanpham.maloai \n" +
                    "       from sanpham, loaisanpham\n" +
                    "       where sanpham.maLoai = loaisanpham.loaiID and maSanPham = " + ID;
      try(Connection conn = DBHelper.OpenConnection(); Statement s = conn.createStatement();){
          ResultSet r = s.executeQuery(sql);
          while(r.next()){
              SanPhamDTO sanPham = new SanPhamDTO();
              sanPham.setMaSanPham(r.getInt("maSanPham"));
              sanPham.setGia(r.getInt("gia"));
              sanPham.setMaLoai(r.getString("maLoai"));
              sanPham.setSoLuong(r.getInt("soLuong"));
              sanPham.setTenSanPham(r.getString("tenSanPham"));
              sanPhamArr.add(sanPham);
          }
      }
      return sanPhamArr;
  }
  
  public Vector<SanPhamDTO> timTheoTen(String ten) throws ClassNotFoundException, SQLException{
      Vector<SanPhamDTO> sanPhamArr = new Vector<SanPhamDTO>();
      String sql =  "select maSanPham, tenSanPham, gia, soluong, loaisanpham.maloai \n" +
                    "       from sanpham, loaisanpham\n" +
                    "       where sanpham.maLoai = loaisanpham.loaiID and tenSanPham like '%" + ten + "%'";
      try(Connection conn = DBHelper.OpenConnection(); Statement s = conn.createStatement();){
          ResultSet r = s.executeQuery(sql);
          while(r.next()){
              SanPhamDTO sanPham = new SanPhamDTO();
              sanPham.setMaSanPham(r.getInt("maSanPham"));
              sanPham.setGia(r.getInt("gia"));
              sanPham.setMaLoai(r.getString("maLoai"));
              sanPham.setSoLuong(r.getInt("soLuong"));
              sanPham.setTenSanPham(r.getString("tenSanPham"));
              sanPhamArr.add(sanPham);
          }
      }
      return sanPhamArr;      
  }
  
   public Vector<SanPhamDTO> timTheoLoai(String maLoai) throws ClassNotFoundException, SQLException{
      Vector<SanPhamDTO> sanPhamArr = new Vector<SanPhamDTO>();
      String sql =  "select maSanPham, tenSanPham, gia, soluong, loaisanpham.maloai \n" +
                    "       from sanpham, loaisanpham\n" +
                    "       where sanpham.maLoai = loaisanpham.loaiID and loaiSanPham.maLoai like '%" + maLoai + "%'";
      try(Connection conn = DBHelper.OpenConnection(); Statement s = conn.createStatement();){
          ResultSet r = s.executeQuery(sql);
          while(r.next()){
              SanPhamDTO sanPham = new SanPhamDTO();
              sanPham.setMaSanPham(r.getInt("maSanPham"));
              sanPham.setGia(r.getInt("gia"));
              sanPham.setMaLoai(r.getString("maLoai"));
              sanPham.setSoLuong(r.getInt("soLuong"));
              sanPham.setTenSanPham(r.getString("tenSanPham"));
              sanPhamArr.add(sanPham);
          }
      }
      return sanPhamArr;      
  }
   
}
