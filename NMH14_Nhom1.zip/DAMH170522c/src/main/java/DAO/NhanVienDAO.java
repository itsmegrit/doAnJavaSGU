/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.NhanVienDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author kienn
 */
public class NhanVienDAO {
    public Vector<NhanVienDTO> getAllNhanVien() throws ClassNotFoundException, SQLException{
        Vector<NhanVienDTO> nhanVienArr = new Vector<NhanVienDTO>();
        String sql = "SELECT * FROM NHANVIEN";
        try(
                Connection conn = DBHelper.OpenConnection();
                Statement stmt = conn.createStatement();
            ){
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                NhanVienDTO nhanVien = new NhanVienDTO();
                nhanVien.setMaNhanVien(rs.getInt("maNhanVien"));
                nhanVien.setHoVaTen(rs.getString("hoVaTen"));
                nhanVien.setNgayThangNamSinh(rs.getString("ngayThangNamSinh"));
                nhanVien.setLuong(rs.getInt("luong"));
                nhanVienArr.add(nhanVien);
            }
        }
        return nhanVienArr;
    }
    
    //Thêm nhân viên vào cơ sở dữ liệu
    public boolean themNhanVien(NhanVienDTO nhanVien) throws ClassNotFoundException, SQLException{
        boolean res = false;
        String sql = "INSERT INTO NHANVIEN(hoVaTen, ngayThangNamSinh, luong) values(?,?,?)";
        try(
            Connection conn = DBHelper.OpenConnection();
            PreparedStatement pstmt = conn.prepareCall(sql);
        ){
            pstmt.setString(1, nhanVien.getHoVaTen());
            pstmt.setString(2, nhanVien.getNgayThangNamSinh());
            pstmt.setInt(3, nhanVien.getLuong());
            if(pstmt.executeUpdate()>=1){
                res = true;
            }
        }
        return res;
    }
//   
//    boolean res = false;
//    String sql = "insert into NHANVIEN (hoVaTen, ngayThangNamSinh, luong) values (?, ?, ?, ?)";
//    try(Connection conn = DBHelper.OpenConnection();PreparedStatement pstmt = conn.prepareCall(sql);){
//        pstmt.setString(1, nhanVien.getHoVaTen());
//        pstmt.setString(2, nhanVien.getNgayThangNamSinh());
//        pstmt.setInt(3, nhanVien.getLuong());
//        if(pstmt.executeUpdate()>=1){
//            res = true;
//        }
//    }
//    return res;
    
    public boolean kiemTraDaCoNhanVien(String hoVaTen) throws ClassNotFoundException, SQLException{
        boolean res = false;
        String sql = "SELECT * FROM NHANVIEN WHERE hoVaTen='" + hoVaTen +"'";
        try(
            Connection conn = DBHelper.OpenConnection(); 
            Statement stmt = conn.createStatement();
        ){
            ResultSet rs = stmt.executeQuery(sql);
            res = rs.next();
        }
        return res;
    }
    public boolean xoaNhanVien(int maNhanVien) throws ClassNotFoundException, SQLException{
      boolean res = false;
      String sql = "DELETE FROM NHANVIEN WHERE maNhanVien =" + maNhanVien;
      try(
          Connection conn = DBHelper.OpenConnection();
          Statement stmt = conn.createStatement();
          ){
          if(stmt.executeUpdate(sql)>= 1){
              res = true;
          }
      }
      return res;
  }
    public boolean suaNhanVien(NhanVienDTO nhanVien) throws ClassNotFoundException, SQLException{
        boolean res = false;
        String sql = "UPDATE NHANVIEN SET hoVaTen = ?, ngayThangNamSinh = ?, luong = ? where maNhanVien = ?";
        try(
                Connection conn = DBHelper.OpenConnection();
                PreparedStatement pstmt = conn.prepareCall(sql);
            ){
            pstmt.setString(1, nhanVien.getHoVaTen());
            pstmt.setString(2, nhanVien.getNgayThangNamSinh());
            pstmt.setInt(3, nhanVien.getLuong());
            pstmt.setInt(4, nhanVien.getMaNhanVien());
            if(pstmt.executeUpdate()>=1){
                res = true;
            }
        }
        return res;
    }
    
    public Vector<NhanVienDTO> timTheoMa(int maNhanVien) throws ClassNotFoundException, SQLException {
        Vector<NhanVienDTO> nhanVienArr = new Vector<NhanVienDTO>();
        String sql = "select * from NHANVIEN where maNhanVien = " + maNhanVien;
        try(
                Connection conn = DBHelper.OpenConnection();
                Statement stmt = conn.createStatement();
                ){
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()) {
                NhanVienDTO nhanVien = new NhanVienDTO();
                nhanVien.setMaNhanVien(rs.getInt("maNhanVien"));
                nhanVien.setHoVaTen(rs.getString("hoVaTen"));
                nhanVien.setNgayThangNamSinh(rs.getString("ngayThangNamSinh"));
                nhanVien.setLuong(rs.getInt("luong"));
                nhanVienArr.add(nhanVien);
            }
        }
        return nhanVienArr;
    }
    
    public Vector<NhanVienDTO> timTheoTen(String tenNhanVien) throws ClassNotFoundException, SQLException {
        Vector<NhanVienDTO> nhanVienArr = new Vector<NhanVienDTO>();
        String sql = "select * from NHANVIEN where hoVaTen like '%"+ tenNhanVien +"%'";
        try(
                Connection conn = DBHelper.OpenConnection();
                Statement stmt = conn.createStatement();
                ){
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()) {
                NhanVienDTO nhanVien = new NhanVienDTO();
                nhanVien.setMaNhanVien(rs.getInt("maNhanVien"));
                nhanVien.setHoVaTen(rs.getString("hoVaTen"));
                nhanVien.setNgayThangNamSinh(rs.getString("ngayThangNamSinh"));
                nhanVien.setLuong(rs.getInt("luong"));
                nhanVienArr.add(nhanVien);
            }
        }
        return nhanVienArr;
    }
}
