/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author ngtph
 */
// database helper
public class DBHelper {
    public static Connection OpenConnection() throws ClassNotFoundException, SQLException{
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String connectionUrl = "jdbc:sqlserver://localhost:1433;DatabaseName=BMT";
        String username = "bmt";
        String password = "bmt";
        Connection conn = DriverManager.getConnection(connectionUrl, username, password);
        return conn;
    }
}
