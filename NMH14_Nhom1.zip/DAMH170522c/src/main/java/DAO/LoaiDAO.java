/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.LoaiDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author ngtph
 */
public class LoaiDAO {
      
  public boolean hasLoai(String maLoai) throws ClassNotFoundException, SQLException{
      boolean res = false;
      String sql = "select * from LOAISANPHAM where maLoai = '" + maLoai + "'";
      try(
          Connection conn = DBHelper.OpenConnection();
          Statement stmt = conn.createStatement();
          ){
          ResultSet rs = stmt.executeQuery(sql);
          if(rs.next()){
              res=true;
          }
      }
      return res;
  }
  
    public LoaiDTO findLoai(int loaiID) throws ClassNotFoundException, SQLException{
      LoaiDTO newLoai = new LoaiDTO();
      String sql = "select * from LOAISANPHAM where loaiID = " + loaiID;
      try(
          Connection conn = DBHelper.OpenConnection();
          Statement stmt = conn.createStatement();
          ){
          ResultSet rs = stmt.executeQuery(sql);
          if(rs.next()){
              newLoai.setLoaiID(rs.getInt("loaiID"));
              newLoai.setMaLoai(rs.getString("maLoai"));
              newLoai.setTenLoai(rs.getString("tenLoai"));
          }
      }
      return newLoai;
    }
    
    public LoaiDTO findLoai(String maLoai) throws ClassNotFoundException, SQLException{
      LoaiDTO newLoai = new LoaiDTO();
      String sql = "select * from LOAISANPHAM where maLoai = '" + maLoai + "'";
      try(
          Connection conn = DBHelper.OpenConnection();
          Statement stmt = conn.createStatement();
          ){
          ResultSet rs = stmt.executeQuery(sql);
          if(rs.next()){
              newLoai.setLoaiID(rs.getInt("loaiID"));
              newLoai.setMaLoai(rs.getString("maLoai"));
              newLoai.setTenLoai(rs.getString("tenLoai"));
          }
      }
      return newLoai;  
    }

    public Vector<LoaiDTO> getAllLoai() throws ClassNotFoundException, SQLException {
        Vector<LoaiDTO> loaiArr = new Vector<LoaiDTO>();
        String sql = "select * from LOAISANPHAM";
        try(
            Connection conn = DBHelper.OpenConnection();
            Statement stmt = conn.createStatement();
            ){
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                LoaiDTO newLoaiDTO = new LoaiDTO();
                newLoaiDTO.setMaLoai(rs.getString("maLoai"));
                newLoaiDTO.setTenLoai("tenLoai");
                loaiArr.add(newLoaiDTO);
            }
        }
        return loaiArr;
    }
    
    public boolean addLoai(LoaiDTO loai) throws ClassNotFoundException, SQLException{
        boolean res = false;
        String sql = "insert into LOAISANPHAM (maLoai, tenLoai) values (?, ?)";
        try(Connection conn = DBHelper.OpenConnection();
                PreparedStatement pstmt = conn.prepareCall(sql);
            ) {
            pstmt.setString(1, loai.getMaLoai());
            pstmt.setString(2, loai.getTenLoai());
            if(pstmt.executeUpdate()>=1){
                res=true;
            }
        }
        return res;
    }
}
